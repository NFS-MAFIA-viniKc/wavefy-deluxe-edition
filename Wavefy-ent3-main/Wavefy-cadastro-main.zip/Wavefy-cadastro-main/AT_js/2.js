let listac=[];
console.log("Por favor liste 3 itens que você deseja")

if (listac[2]!="leite") {
    listac.pop("leite")
    
}