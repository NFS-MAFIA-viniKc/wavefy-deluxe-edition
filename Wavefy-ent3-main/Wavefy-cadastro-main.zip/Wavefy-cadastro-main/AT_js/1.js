let estoquep =["camiseta","calça","sapato"];
estoquep.push("meia");
estoquep.shift(0);
estoquep[1]="bermuda";
console.log(estoquep);